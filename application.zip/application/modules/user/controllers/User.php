<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	/**
	* User list
	*/
	public function index() {
		echo "this is yet to be build";
	}
}
